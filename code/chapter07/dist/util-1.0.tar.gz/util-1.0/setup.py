from distutils.core import setup
setup(
    name='util',
    version='1.0',
    author='wolfcode',
    author_email='wolfcode@wolfcode.cn',
    url='http://www.wolfcode.cn',
    download_url='http://www.wolfcode.cn',
    description='util module',
    py_modules=['util.mathutil', 'util.stringutil',"log"]
)
