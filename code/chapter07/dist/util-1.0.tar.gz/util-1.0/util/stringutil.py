def fun01():
    print("...stringutil...fun01...")


def fun02():
    print("...stringutil...fun02...")


def fun03():
    print("...stringutil...fun03...")