def fun01():
    print("...mathutil...fun01...")


def fun02():
    print("...mathutil...fun02...")


def fun03():
    print("...mathutil...fun03...")